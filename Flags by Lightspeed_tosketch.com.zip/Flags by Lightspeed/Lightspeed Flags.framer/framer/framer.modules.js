require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"flag":[function(require,module,exports){
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

exports.Flag = (function(superClass) {
  extend(Flag, superClass);

  function Flag(options) {
    var base, base1, base2;
    this.options = options != null ? options : {};
    if ((base = this.options).iso == null) {
      base.iso = "CA";
    }
    if ((base1 = this.options).width == null) {
      base1.width = 16;
    }
    if ((base2 = this.options).height == null) {
      base2.height = 12;
    }
    this.options.image = "flags/" + this.options.iso + ".svg";
    this.options.backgroundColor = "transparent";
    Flag.__super__.constructor.call(this, this.options);
  }

  Flag.define('iso', {
    get: function() {
      return this.options.iso;
    },
    set: function(value) {
      this.options.iso = value;
      return this.image = "flags/" + this.options.iso + ".svg";
    }
  });

  return Flag;

})(Layer);


},{}]},{},[])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnJhbWVyLm1vZHVsZXMuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL1VzZXJzL2FsZXhpcy5tb3Jpbi9jb2RlL2ZsYWdzLWJ5LWxpZ2h0c3BlZWQvTGlnaHRzcGVlZCBGbGFncy5mcmFtZXIvbW9kdWxlcy9mbGFnLmNvZmZlZSIsIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgZXhwb3J0cy5GbGFnIGV4dGVuZHMgTGF5ZXJcbiAgICBjb25zdHJ1Y3RvcjogKEBvcHRpb25zID0ge30pIC0+XG4gICAgICAgIEBvcHRpb25zLmlzbyA/PSBcIkNBXCJcbiAgICAgICAgQG9wdGlvbnMud2lkdGggPz0gMTZcbiAgICAgICAgQG9wdGlvbnMuaGVpZ2h0ID89IDEyXG4gICAgICAgIEBvcHRpb25zLmltYWdlID0gXCJmbGFncy8je0BvcHRpb25zLmlzb30uc3ZnXCJcbiAgICAgICAgQG9wdGlvbnMuYmFja2dyb3VuZENvbG9yID0gXCJ0cmFuc3BhcmVudFwiXG4gICAgICAgIHN1cGVyIEBvcHRpb25zXG5cbiAgICBAZGVmaW5lICdpc28nLFxuICAgICAgICBnZXQ6IC0+XG4gICAgICAgICAgICBAb3B0aW9ucy5pc29cbiAgICAgICAgc2V0OiAodmFsdWUpIC0+XG4gICAgICAgICAgICBAb3B0aW9ucy5pc28gPSB2YWx1ZVxuICAgICAgICAgICAgQGltYWdlID0gXCJmbGFncy8je0BvcHRpb25zLmlzb30uc3ZnXCIiLCIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUNBQTtBREFBLElBQUE7OztBQUFNLE9BQU8sQ0FBQzs7O0VBQ0csY0FBQyxPQUFEO0FBQ1QsUUFBQTtJQURVLElBQUMsQ0FBQSw0QkFBRCxVQUFXOztVQUNiLENBQUMsTUFBTzs7O1dBQ1IsQ0FBQyxRQUFTOzs7V0FDVixDQUFDLFNBQVU7O0lBQ25CLElBQUMsQ0FBQSxPQUFPLENBQUMsS0FBVCxHQUFpQixRQUFBLEdBQVMsSUFBQyxDQUFBLE9BQU8sQ0FBQyxHQUFsQixHQUFzQjtJQUN2QyxJQUFDLENBQUEsT0FBTyxDQUFDLGVBQVQsR0FBMkI7SUFDM0Isc0NBQU0sSUFBQyxDQUFBLE9BQVA7RUFOUzs7RUFRYixJQUFDLENBQUEsTUFBRCxDQUFRLEtBQVIsRUFDSTtJQUFBLEdBQUEsRUFBSyxTQUFBO2FBQ0QsSUFBQyxDQUFBLE9BQU8sQ0FBQztJQURSLENBQUw7SUFFQSxHQUFBLEVBQUssU0FBQyxLQUFEO01BQ0QsSUFBQyxDQUFBLE9BQU8sQ0FBQyxHQUFULEdBQWU7YUFDZixJQUFDLENBQUEsS0FBRCxHQUFTLFFBQUEsR0FBUyxJQUFDLENBQUEsT0FBTyxDQUFDLEdBQWxCLEdBQXNCO0lBRjlCLENBRkw7R0FESjs7OztHQVR1QiJ9
