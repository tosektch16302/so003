---
Title: Site Starter
Version: 1.0.0
Author: Simon Eramo
Twitter: twitter/simoneramo
Dribble: dribbble/simoneramo
Site: simoneramo.me
Date: 06/24/2018
Licence: https://creativecommons.org/licenses/by-nc/4.0/
File: Made in Sketch App version 47.1
About: This is a stater sketch file for any project you wish to use it for please reference to licence.
Note: To realize that you are not your thoughts is when you begin to awaken spiritually. Eckhart Tolle
---